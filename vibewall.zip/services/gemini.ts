import { GoogleGenAI } from "@google/genai";
import { GeneratedImage, AspectRatio } from "../types";

// Initialize the client with the API key from the environment
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const generateWallpapers = async (
  prompt: string, 
  aspectRatio: AspectRatio = '9:16'
): Promise<GeneratedImage[]> => {
  try {
    const response = await ai.models.generateImages({
      model: 'imagen-4.0-generate-001',
      prompt: prompt,
      config: {
        numberOfImages: 4,
        aspectRatio: aspectRatio,
        outputMimeType: 'image/jpeg',
      },
    });

    if (!response.generatedImages) {
      throw new Error("No images returned from the API.");
    }

    // Map the response to our internal GeneratedImage type
    return response.generatedImages.map((img, index) => ({
      id: `${Date.now()}-${index}`,
      base64: `data:image/jpeg;base64,${img.image.imageBytes}`,
      prompt: prompt,
      aspectRatio: aspectRatio,
      createdAt: Date.now(),
    }));

  } catch (error: any) {
    console.error("Error generating images:", error);
    throw new Error(error.message || "Failed to generate wallpapers. Please try again.");
  }
};
