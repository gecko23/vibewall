import React, { useState, useEffect } from 'react';
import { Loader2, Sparkles, Smartphone, Monitor, Square } from 'lucide-react';
import { AspectRatio } from '../types';

interface InputSectionProps {
  onGenerate: (prompt: string, aspectRatio: AspectRatio) => void;
  isGenerating: boolean;
  initialPrompt?: string;
}

const VIBES = [
  "Cyberpunk City Rain",
  "Minimalist Zen Garden",
  "Retro Vaporwave Sunset",
  "Deep Space Nebula",
  "Abstract Fluid Neon",
  "Pastel Dreamscape"
];

const ASPECT_RATIOS: { value: AspectRatio; label: string; icon: React.ElementType }[] = [
  { value: '9:16', label: 'Portrait', icon: Smartphone },
  { value: '1:1', label: 'Square', icon: Square },
  { value: '16:9', label: 'Landscape', icon: Monitor },
];

export const InputSection: React.FC<InputSectionProps> = ({ onGenerate, isGenerating, initialPrompt }) => {
  const [prompt, setPrompt] = useState('');
  const [aspectRatio, setAspectRatio] = useState<AspectRatio>('9:16');

  useEffect(() => {
    if (initialPrompt) {
      setPrompt(initialPrompt);
    }
  }, [initialPrompt]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (prompt.trim()) {
      onGenerate(prompt, aspectRatio);
    }
  };

  const handleVibeClick = (vibe: string) => {
    setPrompt(vibe);
  };

  return (
    <div className="w-full bg-gray-900/80 backdrop-blur-md sticky top-0 z-10 border-b border-gray-800 p-4 shadow-lg">
      <form onSubmit={handleSubmit} className="flex flex-col gap-4 max-w-2xl mx-auto">
        <div className="relative">
          <textarea
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder="Describe your vibe... (e.g. 'bioluminescent forest at night')"
            className="w-full bg-gray-800 text-white rounded-xl p-4 pr-12 border border-gray-700 focus:border-primary-500 focus:ring-1 focus:ring-primary-500 outline-none resize-none h-24 text-base transition-all"
            disabled={isGenerating}
          />
          <div className="absolute bottom-3 right-3">
            <Sparkles className="w-5 h-5 text-gray-500" />
          </div>
        </div>

        <div className="flex flex-col gap-2">
          <div className="flex overflow-x-auto gap-2 pb-2 no-scrollbar snap-x">
            {VIBES.map((vibe) => (
              <button
                key={vibe}
                type="button"
                onClick={() => handleVibeClick(vibe)}
                className="snap-start shrink-0 px-3 py-1.5 bg-gray-800 hover:bg-gray-700 border border-gray-700 rounded-full text-xs font-medium text-gray-300 transition-colors whitespace-nowrap"
                disabled={isGenerating}
              >
                {vibe}
              </button>
            ))}
          </div>

          <div className="flex gap-2 overflow-x-auto pb-1 no-scrollbar">
            {ASPECT_RATIOS.map((ratio) => {
              const Icon = ratio.icon;
              return (
                <button
                  key={ratio.value}
                  type="button"
                  onClick={() => setAspectRatio(ratio.value)}
                  disabled={isGenerating}
                  className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium transition-colors border whitespace-nowrap ${
                    aspectRatio === ratio.value 
                      ? 'bg-gray-700 border-primary-500 text-white' 
                      : 'bg-gray-800 border-gray-700 text-gray-400 hover:bg-gray-700'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  {ratio.label}
                </button>
              );
            })}
          </div>
        </div>

        <button
          type="submit"
          disabled={!prompt.trim() || isGenerating}
          className={`w-full py-3 px-6 rounded-xl font-bold text-white shadow-md flex items-center justify-center gap-2 transition-all transform active:scale-95
            ${!prompt.trim() || isGenerating 
              ? 'bg-gray-700 cursor-not-allowed opacity-50' 
              : 'bg-gradient-to-r from-primary-600 to-purple-600 hover:from-primary-500 hover:to-purple-500 shadow-primary-500/20'
            }`}
        >
          {isGenerating ? (
            <>
              <Loader2 className="w-5 h-5 animate-spin" />
              Dreaming...
            </>
          ) : (
            <>
              <Sparkles className="w-5 h-5" />
              Generate Wallpapers
            </>
          )}
        </button>
      </form>
    </div>
  );
};