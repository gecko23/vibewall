import React from 'react';
import { GeneratedImage } from '../types';
import { X, Download, RefreshCw, Share2 } from 'lucide-react';

interface FullScreenViewerProps {
  image: GeneratedImage | null;
  onClose: () => void;
  onRemix: (image: GeneratedImage) => void;
}

export const FullScreenViewer: React.FC<FullScreenViewerProps> = ({ image, onClose, onRemix }) => {
  if (!image) return null;

  const handleDownload = () => {
    const link = document.createElement('a');
    link.href = image.base64;
    link.download = `vibewall-${image.id}.jpg`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/95 flex flex-col items-center justify-center animate-in fade-in duration-200">
      
      {/* Close Button */}
      <button 
        onClick={onClose}
        className="absolute top-4 right-4 z-10 p-2 bg-black/50 hover:bg-gray-800 rounded-full text-white transition-colors"
      >
        <X className="w-6 h-6" />
      </button>

      {/* Image Container */}
      <div className="relative w-full h-full max-w-md flex items-center justify-center p-4">
        <img 
          src={image.base64} 
          alt={image.prompt}
          className="max-h-full w-auto rounded-lg shadow-2xl shadow-primary-900/20 object-contain"
        />
      </div>

      {/* Controls - Sticky Bottom */}
      <div className="absolute bottom-0 left-0 right-0 p-6 bg-gradient-to-t from-black via-black/90 to-transparent pb-10">
        <div className="max-w-md mx-auto flex flex-col gap-4">
          <div className="text-sm text-gray-400 line-clamp-2 text-center px-4">
            "{image.prompt}"
          </div>
          
          <div className="flex gap-3">
            <button 
              onClick={handleDownload}
              className="flex-1 bg-gray-800 hover:bg-gray-700 text-white py-3 px-4 rounded-xl font-bold flex items-center justify-center gap-2 transition-colors"
            >
              <Download className="w-5 h-5" />
              Download
            </button>
            
            <button 
              onClick={() => onRemix(image)}
              className="flex-1 bg-primary-600 hover:bg-primary-500 text-white py-3 px-4 rounded-xl font-bold flex items-center justify-center gap-2 transition-colors"
            >
              <RefreshCw className="w-5 h-5" />
              Remix
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
