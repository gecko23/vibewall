import React from 'react';
import { GeneratedImage } from '../types';
import { Maximize2 } from 'lucide-react';

interface ImageGridProps {
  images: GeneratedImage[];
  onSelect: (image: GeneratedImage) => void;
  isLoading: boolean;
}

export const ImageGrid: React.FC<ImageGridProps> = ({ images, onSelect, isLoading }) => {
  // Skeleton loader for when generating
  if (isLoading && images.length === 0) {
    return (
      <div className="grid grid-cols-2 gap-3 p-3 pb-24 max-w-2xl mx-auto">
        {[1, 2, 3, 4].map((i) => (
          <div key={i} className="aspect-[9/16] rounded-2xl bg-gray-800 animate-pulse overflow-hidden relative">
             <div className="absolute inset-0 bg-gradient-to-t from-gray-900/50 to-transparent" />
          </div>
        ))}
      </div>
    );
  }

  if (images.length === 0 && !isLoading) {
    return (
      <div className="flex flex-col items-center justify-center py-20 px-6 text-center text-gray-500">
        <div className="w-16 h-16 bg-gray-800 rounded-full flex items-center justify-center mb-4">
            <Maximize2 className="w-8 h-8 opacity-50" />
        </div>
        <p className="text-lg font-medium text-gray-400">No vibes yet</p>
        <p className="text-sm max-w-xs mt-2">Enter a prompt above to generate your first batch of unique wallpapers.</p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-2 gap-3 p-3 pb-24 max-w-2xl mx-auto">
      {images.map((img) => (
        <div 
          key={img.id} 
          onClick={() => onSelect(img)}
          style={{ aspectRatio: img.aspectRatio.replace(':', '/') }}
          className="group relative rounded-2xl overflow-hidden cursor-pointer border border-gray-800 hover:border-primary-500/50 transition-all w-full"
        >
          <img 
            src={img.base64} 
            alt={img.prompt} 
            className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
            loading="lazy"
          />
          <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors duration-300" />
        </div>
      ))}
    </div>
  );
};